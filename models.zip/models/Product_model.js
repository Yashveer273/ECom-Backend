const mongoose = require("mongoose");

// --------------------------------------
// Price Schema
// --------------------------------------
const PriceSchema = new mongoose.Schema(
  {
    mrp: { type: Number, required: true },
    sellingPrice: { type: Number, required: true },
    discountPercent: { type: Number, default: 0 },
    currency: { type: String, default: "INR" }
  },
  { _id: false }
);

// --------------------------------------
// Image Schema
// --------------------------------------
const ImageSchema = new mongoose.Schema(
  {
    url: { type: String, required: true },
    alt: String,
    isPrimary: { type: Boolean, default: false }
  },
  { _id: false }
);

// --------------------------------------
// Product Variation (Color, Size, etc.)
// --------------------------------------
const VariationSchema = new mongoose.Schema(
  {
    color: String,
    size: String,
    stock: { type: Number, default: 0 },
    sku: { type: String, required: true },
    images: [ImageSchema]
  },
  { _id: false }
);

// --------------------------------------
// Specification Schema
// --------------------------------------
const SpecificationSchema = new mongoose.Schema(
  {
    key: String,
    value: String
  },
  { _id: false }
);

// --------------------------------------
// Review Schema
// --------------------------------------
const ReviewSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    username: String,
    rating: { type: Number, min: 1, max: 5 },
    comment: String,
    date: { type: Date, default: Date.now }
  },
  { _id: false }
);

// --------------------------------------
// Detail Section (Story, Style Note, Details)
// --------------------------------------
const DetailSectionSchema = new mongoose.Schema(
  {
    story: String,
    details: String,
    styleNote: String
  },
  { _id: false }
);

// --------------------------------------
// MAIN PRODUCT SCHEMA
// --------------------------------------
const ProductSchema = new mongoose.Schema(
  {
    // ✅ Basic Information
    name: { type: String, required: true, index: true },
    brand: String,
    category: { type: String, index: true },
    subCategory: String,
    sku: { type: String, unique: true },
    slug: { type: String, unique: true },

    // ✅ Headings & Highlights
    highlightHeading: String,
    highlights: [String],
    productHeading: String,

    // ✅ Pricing
    price: PriceSchema,

    // ✅ Images
    images: [ImageSchema],

    // ✅ Variations
    variations: [VariationSchema],
    availableColors: [String],

    // ✅ Description & Specs
    description: DetailSectionSchema,
    specifications: [SpecificationSchema],

    // ✅ Vendor Information (without vendor schema)
    vendorId: { type: String, required: true }, // e.g. userId or external vendor ID
    vendorName: String,
    vendorRating: { type: Number, default: 0 },

    // ✅ Publish Info
    publishDate: { type: Date, default: Date.now },

    // ✅ Search Ranking & Marketing Flags
    isSponsored: { type: Boolean, default: false },
    searchBoostScore: { type: Number, default: 0 },
    totalSales: { type: Number, default: 0 },

    // ✅ Status
    isActive: { type: Boolean, default: true },
    stock: { type: Number, default: 0 },
    inStock: { type: Boolean, default: true },

    // ✅ Suggested / Popular
    suggestedProducts: [{ type: mongoose.Schema.Types.ObjectId, ref: "Product" }],
    isFeatured: { type: Boolean, default: false },
    isPopular: { type: Boolean, default: false },
    isTrending: { type: Boolean, default: false },

    // ✅ Ratings & Reviews
    avgRating: { type: Number, default: 0 },
    totalRatings: { type: Number, default: 0 },
    reviews: [ReviewSchema],

    // ✅ Warranty / Returns
    warrantyYears: { type: Number, default: 0 },
    returnPolicyDays: { type: Number, default: 7 },

    // ✅ SEO & Metadata
    keywords: [String],
    tags: [String],

    // ✅ Added By (Admin or Seller User ID)
    addedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
  },
  { timestamps: true }
);

// --------------------------------------
// Auto-generate slug before saving
// --------------------------------------
ProductSchema.pre("save", function (next) {
  if (!this.slug && this.name) {
    this.slug = this.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");
  }
  next();
});

// --------------------------------------
// Text index for search optimization
// --------------------------------------
ProductSchema.index({
  name: "text",
  brand: "text",
  category: "text",
  keywords: "text",
  vendorName: "text"
});

module.exports = mongoose.model("Product", ProductSchema);
